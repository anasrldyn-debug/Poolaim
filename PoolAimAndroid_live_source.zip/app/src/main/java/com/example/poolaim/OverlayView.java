package com.example.poolaim;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Transparent proof-of-concept overlay. Aim lines are placeholders until ball detection is implemented. */
public class OverlayView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    public OverlayView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float d = getResources().getDisplayMetrics().density;
        p.setColor(0xDD00DFA5); p.setStrokeWidth(2.5f*d); p.setStyle(Paint.Style.STROKE);
        // Demonstration guides only; not based on detected game balls.
        c.drawLine(getWidth()*0.15f, getHeight()*0.72f, getWidth()*0.82f, getHeight()*0.28f, p);
        c.drawLine(getWidth()*0.15f, getHeight()*0.72f, getWidth()*0.80f, getHeight()*0.72f, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(13*d);
        c.drawText("Pool Aim prototype • guides are illustrative", 12*d, 28*d, p);
    }
}
