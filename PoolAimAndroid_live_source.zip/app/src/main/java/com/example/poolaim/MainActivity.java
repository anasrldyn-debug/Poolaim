package com.example.poolaim;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 1001;
    private static final int REQUEST_OVERLAY = 1002;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("Pool Aim Live"); title.setTextSize(27); title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1, 72));

        status = new TextView(this);
        status.setText("نموذج أولي لالتقاط الشاشة وعرض طبقة عائمة. لا يكتشف الكرات تلقائيًا بعد.");
        status.setTextColor(0xFFE2E8EC); status.setTextSize(16); status.setPadding(0, 16, 0, 24);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        Button start = new Button(this); start.setText("تشغيل الطبقة العائمة");
        start.setOnClickListener(v -> beginSetup());
        root.addView(start, new LinearLayout.LayoutParams(-1, 56));

        Button stop = new Button(this); stop.setText("إيقاف الطبقة العائمة");
        stop.setOnClickListener(v -> { stopService(new Intent(this, CaptureService.class)); status.setText("تم طلب إيقاف الخدمة."); });
        root.addView(stop, new LinearLayout.LayoutParams(-1, 56));
        setContentView(root);
    }

    private void beginSetup() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQUEST_OVERLAY); return;
        }
        requestCapturePermission();
    }

    private void requestCapturePermission() {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapturePermission();
            else Toast.makeText(this, "لازم تسمح بالعرض فوق التطبيقات", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("projectionData", data);
            startForegroundService(service);
            status.setText("تم طلب بدء التقاط الشاشة والطبقة العائمة. خطوط التصويب الذكية لم تُنفذ بعد.");
        } else if (requestCode == REQUEST_CAPTURE) {
            status.setText("تم إلغاء إذن التقاط الشاشة.");
        }
    }
}
