package com.example.poolaim;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

public class PoolView extends View {
    private Bitmap bitmap;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] cue = null, target = null, pocket = null;
    private float scale = 1f, offX = 0f, offY = 0f;

    public PoolView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

    public void setBitmap(Bitmap b) {
        bitmap = b;
        resetPoints();
        invalidate();
    }

    public void resetPoints() {
        cue = target = pocket = null;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0xFF18252D);
        if (bitmap == null) {
            paint.setColor(Color.LTGRAY);
            paint.setTextSize(18f * getResources().getDisplayMetrics().density);
            canvas.drawText("اختر لقطة شاشة أولاً", 24, 48, paint);
            return;
        }

        float sx = getWidth() / (float) bitmap.getWidth();
        float sy = getHeight() / (float) bitmap.getHeight();
        scale = Math.min(sx, sy);
        float w = bitmap.getWidth() * scale, h = bitmap.getHeight() * scale;
        offX = (getWidth() - w) / 2f;
        offY = (getHeight() - h) / 2f;
        canvas.save();
        canvas.translate(offX, offY);
        canvas.scale(scale, scale);
        canvas.drawBitmap(bitmap, 0, 0, paint);

        if (cue != null) drawPoint(canvas, cue, Color.WHITE, "1");
        if (target != null) drawPoint(canvas, target, 0xFFFFD54F, "2");
        if (pocket != null) drawPoint(canvas, pocket, 0xFF00E676, "3");

        if (cue != null && target != null) {
            drawLine(canvas, cue, target, Color.WHITE, 3.5f);
            // Illustrative line beyond target; real collision geometry is not yet modeled.
            float dx = target[0] - cue[0], dy = target[1] - cue[1];
            float len = (float)Math.sqrt(dx*dx + dy*dy);
            if (len > 0) {
                float ex = target[0] + dx / len * 160f;
                float ey = target[1] + dy / len * 160f;
                paint.setColor(0x99FFFFFF); paint.setStrokeWidth(2.2f);
                canvas.drawLine(target[0], target[1], ex, ey, paint);
            }
        }
        if (target != null && pocket != null) {
            drawLine(canvas, target, pocket, 0xFF00E676, 3.5f);
        }
        canvas.restore();

        paint.setColor(0xEE101820);
        canvas.drawRoundRect(8, 8, getWidth()-8, 42, 12, 12, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(13f * getResources().getDisplayMetrics().density);
        String next = cue == null ? "المس الكرة البيضاء" : target == null ? "المس الكرة الهدف" : pocket == null ? "المس الجيب" : "خطوط تقريبية • أعد التحديد لتجربة أخرى";
        canvas.drawText(next, 18, 30, paint);
    }

    private void drawPoint(Canvas c, float[] p, int color, String label) {
        paint.setColor(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3f);
        c.drawCircle(p[0], p[1], 14f, paint);
        paint.setStyle(Paint.Style.FILL); paint.setTextSize(20f); paint.setFakeBoldText(true);
        c.drawText(label, p[0]+16, p[1]-12, paint);
        paint.setFakeBoldText(false);
    }

    private void drawLine(Canvas c, float[] a, float[] b, int color, float width) {
        paint.setColor(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(width);
        Path path = new Path(); path.moveTo(a[0], a[1]); path.lineTo(b[0], b[1]); c.drawPath(path, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP || bitmap == null) return true;
        float x = (e.getX() - offX) / scale;
        float y = (e.getY() - offY) / scale;
        if (x < 0 || y < 0 || x > bitmap.getWidth() || y > bitmap.getHeight()) return true;
        if (cue == null) cue = new float[]{x,y};
        else if (target == null) target = new float[]{x,y};
        else if (pocket == null) pocket = new float[]{x,y};
        else { cue = new float[]{x,y}; target = pocket = null; }
        invalidate();
        return true;
    }
}
